//
//  main.m
//  example
//
//  Created by english on 2023-05-23.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSFileHandle *input = [NSFileHandle fileHandleWithStandardInput];
        NSLog(@"Enter a string");
        NSData *inputData = [input availableData];
        NSString *inputString = [[NSString alloc] initWithData:inputData encoding:<#(NSStringEncoding)#>];
        
        NSLog(@"Enter an integer: ");
        inputData = [input availableData];
        NSString *integerString = [[NSString alloc] initWithData:inputData encoding:NSUTF8StringEncoding];
        NSString *trimmedInputString = [integerString stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
        NSInteger inputInteger = [trimmedInputString integerValue];
    }
    return 0;
}
