//
//  main.m
//  June_first
//
//  Created by english on 2023-06-01.
//

#import <Foundation/Foundation.h>
#import "Etudiant.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        [Etudiant etudiant] = [[Etudiant alloc] init];
        [Etudiant ]
    }
    return 0;
}
