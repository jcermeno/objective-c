//
//  main.m
//  Etudaint_code
//
//  Created by english on 2023-06-01.
//

#import <Foundation/Foundation.h>
#import "Etudiant.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Etudiant *etudiant = [[Etudiant alloc] init];
        [etudiant setIntegerValue:12];
        [etudiant setFloatValue:25.36];
        [etudiant setStringValue:@"Dale Duro"];
        
        NSInteger intval = [etudiant getIntegerValue];
        float floatVal = [etudiant getFloatValue];
        NSString* stringVal = [etudiant getStringValue];
        
        NSLog(@"la intger est: %ld", intval);
        NSLog(@"la float est: %f", floatVal);
        NSLog(@"la string est: %@", stringVal);
    }
    return 0;
}
