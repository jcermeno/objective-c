//
//  Etudiant.h
//  June_01
//
//  Created by english on 2023-06-01.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Etudiant : NSObject
@property(nonatomic, assign) NSInteger integerValue;
@property(nonatomic, assign) float floatValue;
@property(nonatomic, assign) NSString *stringValue;

-(void) setIntegerValue:(NSInteger)integerValue;
-(NSInteger)getIntegerValue;

-(void) setFloatValue:(float)floatValue;
-(float) getFloatValue;

-(void) setStringValue:(NSString *)stringValue;
-(NSString *) getStringValue;

@end

NS_ASSUME_NONNULL_END
