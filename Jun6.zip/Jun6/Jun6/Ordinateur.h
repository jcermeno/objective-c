//
//  Ordinateur.h
//  Jun6
//
//  Created by english on 2023-06-06.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Ordinateur : NSObject
@property(nonatomic, assign) NSString *Model;
@property(nonatomic, assign) NSString *SN;
@property(nonatomic, assign) NSInteger Size_decran;
@property(nonatomic, assign) float Price;

-(void) setModel:(NSString *)Model;
-(NSString*)getModel;

-(void) setSN:(NSString *)SN;
-(NSString*)getSN;

-(void) setSize_decran:(NSInteger)Size_decran;
-(NSInteger)getSize_decran;

-(void)setPrice:(float)Price;
-(float)getPrice;

@end

NS_ASSUME_NONNULL_END
