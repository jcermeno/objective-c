//
//  main.m
//  Jun6
//
//  Created by english on 2023-06-06.
//

#import <Foundation/Foundation.h>
#import "Ordinateur.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Ordinateur *ordinateur = [[Ordinateur alloc] init];
        [ordinateur setModel:@"Samsung"];
        [ordinateur setSN:@"123456789"];
        [ordinateur setSize_decran:21];
        [ordinateur setPrice:983.25];
        
        NSString *model = [ordinateur getModel];
        NSString *sn = [ordinateur getSN];
        NSInteger size_decran = [ordinateur getSize_decran];
        float price = [ordinateur getPrice];
        
        NSLog(@"le Model est : %@", model);
        NSLog(@"le SN est : %@", sn);
        NSLog(@"la Size d'ecran est : %ld", size_decran);
        NSLog(@"le Price est : %f", price);
        
    }
    return 0;
}
