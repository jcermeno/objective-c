//
//  main.m
//  MidtermExamSesion2Question1
//
//  Created by english on 2023-07-06.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        @interface Person : NSObject
        @property NSSString *firsname;
        @property NSSString *lastname;
        @property int departementCode;
        
        
    }
    return 0;
}
