//
//  Ordinateur.m
//  Jun6
//
//  Created by english on 2023-06-06.
//

#import "Ordinateur.h"

@implementation Ordinateur

-(void) setModel:(NSString *)Model{
    _Model = Model;
}
-(NSString *) getModel{
    return _Model;
}

-(void) setSN:(NSString *)SN{
    _SN = SN;
}

-(NSString *) getSN{
    return _SN;
}

-(void) setSize_decran:(NSInteger)Size_decran{
    _Size_decran = Size_decran;
}

-(NSInteger)getSize_decran{
    return _Size_decran;
}

-(void)setPrice:(float)Price{
    _Price = Price;
}

-(float) getPrice{
    return _Price;
}

@end
