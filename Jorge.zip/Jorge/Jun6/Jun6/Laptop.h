//
//  Laptop.h
//  Jun6
//
//  Created by english on 2023-06-06.
//

#ifndef Laptop_h
#define Laptop_h


#endif /* Laptop_h */
