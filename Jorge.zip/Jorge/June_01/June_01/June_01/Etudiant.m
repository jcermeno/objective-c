//
//  Etudiant.m
//  June_01
//
//  Created by english on 2023-06-01.
//

#import "Etudiant.h"

@implementation Etudiant 

@end
