//
//  Etudiant.h
//  June_01
//
//  Created by english on 2023-06-01.
//

#ifndef Etudiant_h
#define Etudiant_h

@implementation Etudiant : NSObject

@end


#endif /* Etudiant_h */
