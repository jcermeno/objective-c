//
//  main.m
//  June_01
//
//  Created by english on 2023-06-01.
//

#import <Foundation/Foundation.h>
#import "Etudiant.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Etudiant *etudiant = [[Etudiant alloc] init];
        [etudiant setIntegerValue: 30];
        [etudiant setIntegerValue:29];
        [etudiant setFloatValue:14.56];
        [etudiant setStringValue:@"j adore objetive C!"];
        
        NSInteger intVal = [etudiant getIntegerValue];
        float floatVal = [etudiant getFloatValue];
        NSString *stringVal = [etudiant getStringValue];
        
        NSLog(@"la integer valuer est: %ld", intVal);
        NSLog(@"la float valuer est: %f", floatVal);
        NSLog(@"la string valuer est: %@", stringVal);
    }
    return 0;
}
