//
//  Etudiant.m
//  Etudaint_code
//
//  Created by english on 2023-06-01.
//

#import "Etudiant.h"


@implementation Etudiant

-(void) setIntegerValue:(NSInteger)integerValue{
    _integerValue = integerValue;
}
-(NSInteger)getIntegerValue{
    return _integerValue;
}
-(void) setFloatValue:(float)floatValue{
    _floatValue = floatValue;
}
-(float) getFloatValue{
    return _floatValue;
}
-(void) setStringValue:(NSString *)stringValue{
    _stringValue = stringValue;
}
-(NSString *) getStringValue{
    return _stringValue;
}

@end
