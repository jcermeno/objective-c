//
//  SceneDelegate.h
//  juilliet_13
//
//  Created by english on 2023-07-13.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

