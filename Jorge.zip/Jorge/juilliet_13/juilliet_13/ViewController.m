//
//  ViewController.m
//  juilliet_13
//
//  Created by english on 2023-07-13.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *firstname;
@property (weak, nonatomic) IBOutlet UITextField *lastname;
@property (weak, nonatomic) IBOutlet UITextField *age;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)registerbtn:(id)sender {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *fileName = [NSString
                          stringWithFormat:@"%/Users/english/Desktop/text.txt",
                          documentsDirectory];
    
    NSString *content = [NSString stringWithFormat:@"%@ %@ %@", _firstname.text, _lastname.text, _age.text];
    
    [content writeToFile:fileName atomically:NO
                encoding:NSStringEncodingConversionAllowLossy
                   error:nil];
}
- (IBAction)clearTextboxes:(id)sender {
    _firstname.text = @"";
    _lastname.text = @"";
    _age.text = @"";
}

@end
